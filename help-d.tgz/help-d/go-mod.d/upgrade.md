## Golang

以下を前提とする。

```
GO111MODULE=on
GOFLAGS=-mod=vendor
```

以下のコマンドでマイナーとパッチのアップロードができる。

```
export GO111MODULE=on
export GOFLAGS=
go list -u -m -json all > outdate01
cat outdate01 | jq -r 'select((.Update != null) and .Indirect != true) | "\(.Update.Path)\t\(.Update.Version)"' | while read i j ; do go get -u $i@$j ; done
go list -u -m -json all > outdate02
diff -urN outdate01 outdate02
```

更新は以下のように行う。Golangの場合、go.modが他のパッケージマネージャーのlockファイルの役目を果たし、各パッケージの更新は自由に `go get -u` で行うことができる。

```
# 全てのパッケージのマイナーとパッチを更新
GOFLAGS= go get -u

# 全てのパッケージのパッチを更新
GOFLAGS= go get -u=patch

# libraryとそのlibraryに依存しているパッケージ(directとindirect)の更新
GOFLAGS= go get -u foo
```

更新が必要なパッケージの一覧は以下で取得する。

```
# マイナーとパッチの更新が可能なパッケージ一覧
go list -u -m all
```

上記の詳細は以下を参照のこと

* https://github.com/golang/go/wiki/Modules#semantic-import-versioning
* https://github.com/golang/go/wiki/Modules#how-to-upgrade-and-downgrade-dependencies
* https://github.com/golang/go/wiki/Modules#why-does-go-mod-tidy-record-indirect-and-test-dependencies-in-my-gomod
* https://github.com/thepudds/go-module-knobs/blob/master/README.md
