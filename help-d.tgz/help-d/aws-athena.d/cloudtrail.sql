-- vim: set filetype=sql :

-- List error
SELECT *
FROM cloudtrail_logs
WHERE errorcode IS NOT NULL
        AND region = 'ap-northeast-1'
        AND year = '2020'
        AND month = '01';

-- Which IAM roles have been active within the last 7 days?
SELECT DISTINCT useridentity.sessioncontext.sessionissuer.arn
FROM cloudtrail_logs
WHERE useridentity.type = 'AssumedRole'
        AND from_iso8601_timestamp(eventtime) > date_add('day', -7, now())
        AND region = 'ap-northeast-1'
        AND year = '2020'
        AND month = '01';

-- Which IAM users have been active within the last 30 days?
SELECT DISTINCT useridentity.arn
FROM cloudtrail_logs
WHERE useridentity.type = 'IAMUser'
        AND useridentity.arn IS NOT NULL
        AND from_iso8601_timestamp(eventtime) > date_add('day', -30, now())
        AND region = 'ap-northeast-1'
        AND year = '2020'
        AND month = '01';

-- Was the root user accessing the account within the last 7 days?
SELECT DISTINCT COUNT(*)
FROM cloudtrail_logs
WHERE useridentity.type = 'Root'
        AND useridentity.invokedby != 'support.amazonaws.com'
        AND from_iso8601_timestamp(eventtime) > date_add('day', -7, now())
        AND year = '2020'

-- Which services and actions is an IAM role accessing?
SELECT DISTINCT eventsource, eventname
FROM cloudtrail_logs
WHERE year = '2020'
        AND (useridentity.sessioncontext.sessionissuer.arn = '<ROLE_ARN>')
ORDER BY eventsource, eventname;

-- Which IAM users have logged into the Management Console within the last 30
-- days?
SELECT DISTINCT useridentity.arn
FROM cloudtrail_logs
WHERE year = '2020'
        AND eventsource = 'signin.amazonaws.com'
        AND eventname = 'ConsoleLogin'
        AND responseelements NOT LIKE '%ConsoleLogin%Failure%'
        AND from_iso8601_timestamp(eventtime) > date_add('day', -30, now());

-- Which identities are doing the most AssumeRole requests. You might be
-- surprised by the data.
SELECT useridentity.sessioncontext.sessionissuer.arn, count(useridentity.sessioncontext.sessionissuer.arn) as count
FROM cloudtrail_logs
WHERE year = '2020'
        AND eventname = 'AssumeRole'
        AND errorcode IS NULL
        AND from_iso8601_timestamp(eventtime) > date_add('day', -30, now())
GROUP BY useridentity.sessioncontext.sessionissuer.arn;

-- Which AssumeRole attempts are failing?
SELECT useridentity.sessioncontext.sessionissuer.arn,
         count(useridentity.sessioncontext.sessionissuer.arn) AS count
FROM cloudtrail_logs
WHERE year = '2020'
        AND eventname = 'AssumeRole'
        AND errorcode = 'AccessDenied'
        AND from_iso8601_timestamp(eventtime) > date_add('day', -14, now())
GROUP BY  useridentity.sessioncontext.sessionissuer.arn;

SELECT count (*) as totalevents, useridentity.arn, eventsource, eventname, errorcode, errormessage
FROM cloudtrail_logs
WHERE errorcode <> '' AND year = '2020'
GROUP by eventsource, eventname, errorcode, errormessage, useridentity.arn
ORDER by eventsource, eventname

-- Identify CloudTrail monthly cost increases
SELECT eventname,
         count(eventname) AS numberofchanges,
         eventsource
FROM cloudtrail_logs
WHERE region = 'ap-northeast-1'
        AND year = '2020'
GROUP BY  eventname, eventsource
ORDER BY  numberofchanges DESC
