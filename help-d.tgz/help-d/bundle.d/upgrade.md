## Rubyのアップデート

CVEの発生などの際は、以下のものをアップデートしてください

* `.ruby-version`
以下のように、任意のバージョンに更新してください

```diff
-2.4.5
+2.4.9
```

* `Gemfile.lock`

以下のコマンドを実行してください

```
$ bundle update --ruby
```


`Gemfile.lock`が更新されます

```diff
-ruby 2.4.5p335
+ruby 2.4.9p362
```

* `Dockerfile`

以下のように、任意のバージョンに更新してください

```diff
-ENV RBENV_VERSION 2.4.5
+ENV RBENV_VERSION 2.4.9
```

## 依存パッケージのアップデート

基本的な方針は以下。

* メジャーは手動で更新する
* マイナーとパッチはコマンドで自動で更新する
* Semantic Versioningに沿っていないパッケージは対象外

全てのパッケージのマイナーとパッチのアップデートは以下のコマンドで行う。基本的にアップグレードはこのコマンドでOK。

```
bundle outdated --filter-minor --filter-patch > outdate01
bundle update --minor $(awk '/  \* / { print $2 }' outdate01)
bundle outdated --filter-minor --filter-patch > outdate02
diff -u outdate02 outdate01
```

Gemfileで適切に指定されている個々のパッケージのアップデートは以下のコマンドで行う

```
# Gemfileの指定によって更新するバージョンが決定
bundle update foo
```

Gemfileで適切に指定されていない個々のパッケージのアップデートは以下のコマンドで行う

```
# メジャーとマイナーとパッチの更新
bundle update foo

# マイナーとパッチの更新
bundle update --minor foo

# パッチの更新
bundle update --patch foo
```

パッケージのバージョン指定は、Gemfileに以下のように行う。

```
# メジャーとマイナーとパッチの更新の許可
gem 'foo', '>= 2.2.0'

# マイナーとパッチの更新の許可
# equals to "gem 'foo', '>= 2.2.0', '< 3.0'"
gem 'foo', '~> 2.2'

# パッチの更新の許可
# equals to "gem 'foo', '>= 2.2.0', '< 2.3.0'"
gem 'foo', '~> 2.2.0'
```

更新が必要なパッケージの一覧は以下で取得する

```
# メジャーとマイナーとパッチの更新
bundle outdated --only-explicit

# マイナーとパッチの更新
bundle outdated --filter-minor --filter-patch --only-explicit

# パッチの更新
bundle outdated --filter-patch --only-explicit
```

上記の詳細については以下を参照のこと

* https://semver.org/
* https://guides.rubygems.org/patterns/#semantic-versioning
* https://bundler.io/man/bundle-update.1.html#PATCH-LEVEL-EXAMPLES
* https://bundler.io/man/bundle-install.1.html#CONSERVATIVE-UPDATING
