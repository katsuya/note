if [[ ! -d "${HOME}/.nodenv" ]]; then
  export NODENV_ROOT=/usr/local/nodenv
  export PATH="$NODENV_ROOT/bin:$PATH"
  eval "$(nodenv init -)"
fi
