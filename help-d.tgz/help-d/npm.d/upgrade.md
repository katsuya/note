## JavaScript

以下のコマンドで全てのパッケージのマイナーとパッチのupgradeができる。pakcage.jsonでは必ず各パッケージのバージョンにcaretの制約(^2.2の形式のバージョン指定)をかけること。

```
npm outdate > outdate01
npm update
npm outdate > outdate02
diff -urN outdate01 outdate02
```

package.jsonには以下のように指定する。というか以下のように指定しないと行けない。bundlerみたいに雑に指定して、アップデート時に細かく更新するものを選んだりできない。

```
# メジャーとマイナーとパッチの更新
"foo": ">=2.2.0"

# マイナーとパッチの更新
"foo": "^2.2"

# パッチの更新
"foo": "~2.2"
```

単体のパッケージの更新は以下のコマンドで行う。

```
npm update foo
npm update --depth 999 foo # 再帰的に更新を行う場合

# yarnは、majorの更新時のみpackage.jsonを更新するので、マイナーとパッチの更新時は特別な対応が必要。
# https://github.com/yarnpkg/yarn/issues/2042#issuecomment-449798652
yarn global add syncyarnlock # install syncyarnlock globally
yarn upgrade # update dependencies, updates yarn.lock
syncyarnlock -s -k # updates package.json with versions installed from yarn.lock
yarn install # updates yarn.lock with current version constraint from package.json
```

更新が必要なパッケージの一覧は以下で取得する。

```
npm outdated
yarn outdated
```

上記の詳細については以下を参照のこと

* https://semver.npmjs.com
* https://docs.npmjs.com/about-semantic-versioning
* https://docs.npmjs.com/files/package-lock.json#optional
