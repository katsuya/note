以下の形式のパッケージ

```
@scoped-namem/package-name
```

* https://docs.npmjs.com/about-scopes
