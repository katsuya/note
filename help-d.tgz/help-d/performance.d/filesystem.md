
## Workload Characterization

実行されるI/Oのパターンを定義するためのチェックリスト

* Operation rate and operation types
* File I/O throughput
* File I/O size
* Read/write ratio
* Synchronous write ratio
* Random versus sequential file offset access

* What is the file system cache hit ratio? Miss rate?
* What are the file system cache capacity and current usage?
* What other caches are present(directory, inode, buffer) and what are their statistics?
* Which applications or users are using the file system?
* What files and directories are being accessed? Created and deleted?
* Have any errors been encountered? Was this due to invalid requests, or issues from the file system?
* Why is file system I/O issued (user-level call path)?
* To what degree is the file system I/O application synchronous?
* What is the distribution of I/O arrival times

* What is the average file system operation latency?
* Are there any high-latency outliers?
* What is the full distribution of operation latency?
* Are system resource controls for file system or disk I/O present and active?

## Static Performance Tuning

きちんと設定されているかどうかを確認するためのチェックリスト

* How many file systems are mounted and actively used?
* What is the file system record size?
* Are access timestamps enabled?
* What other file system options are enabled (compression, encryption, ...)?
* How has the file system cache been configured? Maximum size?
* How have other caches (directory, inode, buffer) been configured?
* Is a second-level cache present and in use?
* Which file system types are used?
* What is the version of the file system (or kernel)?
* Are there file system bugs/patches that should be considered?
* Are there resource controls in use for file system I/O?
* How many storage devices are present and in use?
    * What is the storage device configuration? RAID?

## Micro-Benchmarking

ベンチマーク時に考慮すべき典型的なファクターの一覧

* Operation types
    * the rate of reads, writes, and other file system operations
    * Write type
        * asynchronous or synchronous (O_SYNC)
* I/O size
    * 1 byte up to 1 Mbyte and larger
* File offset pattern
    * random or sequential
* Random-access pattern
    * uniform random or Pareto distribution
* Working set size
    * how well it fits in the file system cache
* Concurrency
    * number of I/O in flight, or number of threads performing
* I/O Memory mapping
    * file access via mmap(), instead of read()/write()
* Cache state
    * whether the file system cache is "cold" (unpopulated) or "warm"
* File system tunables
    * may include compression, data deduplication, and so on
