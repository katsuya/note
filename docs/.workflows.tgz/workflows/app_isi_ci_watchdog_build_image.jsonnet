local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

local tld = 'app_isi/watchdog';
local paths = ['%s/**/*' % tld];
local sa = 'oidc-github-actions@hc-app-isi-dev.iam.gserviceaccount.com';

{
  name: 'App Isi CI Watchdog Build Image',
  on: workflow.onPushWithMain + workflow.onPRWithSelf(std.thisFile) {
    pull_request+: { paths+: paths },
  },
  defaults: workflow.defaults {
    run+: {
      'working-directory': tld,
    },
  },
  concurrency: workflow.concurrency,
  jobs: {
    build_test_push: job.ubuntu + job.gcloudWithoutKubectrl(sa) + job.disableIfDependabot {
      name: 'Build and Push image',
      permissions+: {
        packages: 'write',
      },
      steps+: [
        {
          name: 'Set up Docker Buildx',
          // https://github.com/docker/setup-buildx-action
          uses: 'docker/setup-buildx-action@v3',
        },
        {
          name: 'Login to GitHub Container Registry',
          // https://github.com/docker/login-action
          uses: 'docker/login-action@v3',
          with: {
            registry: 'ghcr.io',
            username: '${{ github.actor }}',
            password: '${{ secrets.github_token }}',
          },
        },
        {
          name: 'Login to Google Artifact Registry',
          uses: 'docker/login-action@v3',
          with: {
            registry: 'asia-docker.pkg.dev',
            username: 'oauth2accesstoken',
            password: '${{ steps.google_github_actions_auth.outputs.access_token }}',
          },
        },
        {
          name: 'Build and Push',
          // https://github.com/docker/build-push-action
          uses: 'docker/build-push-action@v6',
          with: {
            context: './%s' % tld,
            push: true,
            'cache-from': 'type=registry,ref=ghcr.io/hicustomer/hc-app-isi-watchdog:latest',
            'cache-to': 'type=registry,ref=ghcr.io/hicustomer/hc-app-isi-watchdog:latest,mode=max',
            platforms: |||
              linux/amd64
              linux/arm64/v8
            |||,
            tags: |||
              ghcr.io/hicustomer/hc-app-isi-watchdog:git-commit-id-${{ github.sha }}
              asia-docker.pkg.dev/hc-shared-artifact/hc-app-isi/hc-app-isi-watchdog:git-commit-id-${{ github.sha }}
            |||,
          },
        },
      ],
    },
  },
}
