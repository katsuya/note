local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

{
  name: 'Tool Lfs Warning',
  on: workflow.onPushWithMain {
    pull_request+: {
      paths+: [
        '*',
      ],
    },
  },
  defaults: workflow.defaults,
  concurrency: workflow.concurrency,
  jobs: {
    lfs_warning: job.ubuntu {
      name: 'Lfs Warning',
      permissions+: {
        issues: 'write',
        'pull-requests': 'read',
      },
      steps+: [
        {
          name: 'Lfs Warning',
          uses: 'ppremk/lfs-warning@v3.1',
          with: {
            filesizelimit: '1MB',
            exclusionPatterns: |||
              **/package-lock.json
              app_isi/watchdog/generated/autorest/aiven/src/models/mappers.ts
              app_isi/watchdog/schema/*.json
              app_isi/backend/assets/NotoSansJP-Medium.otf
              app_isi/frontend_vendor/generated/graphql.ts
            |||,
          },
        },
      ],
    },
  },
}
