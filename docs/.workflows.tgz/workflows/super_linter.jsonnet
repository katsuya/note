local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

{
  name: 'Super Linter',
  on: workflow.onPushWithMain {
    pull_request+: {
      paths+: [
        '*',
      ],
    },
  },
  defaults: workflow.defaults,
  concurrency: workflow.concurrency,
  env: {
    // Will parse the entire repository and find all files to validate across all
    // types. NOTE: When set to false, only new or edited files will be parsed for
    // validation.
    VALIDATE_ALL_CODEBASE: false,
  },
  jobs: {
    lint_common: job.ubuntu {
      name: 'Lint Common',
      permissions+: {
        'pull-requests': 'write',
      },
      steps: [
        {
          uses: 'actions/checkout@v4',
          with: {
            // Full git history is needed to get a proper list of changed
            // files within `super-linter`
            'fetch-depth': 0,
          },
        },
        {
          name: 'Lint',
          // https://github.com/github/super-linter
          uses: 'github/super-linter@v4.8.5',
          env: {
            GITHUB_TOKEN: '${{ secrets.GITHUB_TOKEN }}',
            // Flag to enable or disable the linting process of the Bash language.
            VALIDATE_BASH: true,
            // Flag to enable or disable the linting process of the Bash language to
            // validate if file is stored as executable.
            VALIDATE_BASH_EXEC: true,
            // Flag to enable or disable the linting process of the JSON language.
            VALIDATE_JSON: true,
            // Flag to enable or disable the linting process of the YAML language.
            VALIDATE_YAML: true,
            FILTER_REGEX_EXCLUDE: '.*frontend_ws/lexical.*',
          },
        },
      ],
    },
  },
}
