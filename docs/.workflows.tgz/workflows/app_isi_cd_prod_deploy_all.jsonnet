local appIsi = import 'app_isi.libsonnet';
local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

local tld = '/app';
local sa = 'oidc-github-actions@hc-app-isi-prod.iam.gserviceaccount.com';

{
  name: 'App Isi CD Prod Deploy All',
  on: {
    push+: {
      branches+: [
        'deploy/app_isi/prod01',
        'deploy/app_isi/prod02',
      ],
    },
  },
  env: {
    NODE_OPTIONS: '--max-old-space-size=4096',
  },
  defaults: workflow.defaults {
    run+: {
      'working-directory': tld,
    },
  },
  concurrency: workflow.concurrency,
  jobs: {
    deploy: appIsi.container('${{ github.sha }}') + job.setAppEnv + job.ubuntuWithoutCheckout + job.gcloud(sa) {
      name: 'Deploy',
      'timeout-minutes': 20,
      environment: 'prod',
      steps+: [
        {
          uses: 'google-github-actions/get-gke-credentials@v2',
          with: {
            cluster_name: 'projects/hc-app-isi-prod/locations/asia-northeast1/clusters/cluster-auto-01',
          },
        },
        { run: 'kubectl get pods' },
        {
          name: 'Check APP_ENV',
          run: |||
            [[ $APP_ENV = prod01 ]] || [[ $APP_ENV = prod02 ]] || \
              { echo "APP_ENV should be prod01 or prod02"; exit 1; }
          |||,
        },
        {
          run: 'make "release_prod_frontend"',
          env: {
            VITE_SENTRY_AUTH_TOKEN: '${{ secrets.VITE_SENTRY_AUTH_TOKEN }}',
            VITE_SENTRY_RELEASE_VERSION: '${{ github.sha }}',
            APP_ENV: 'prod',
          },
        },
        {
          run: 'echo yes | make apply_prod',
          'working-directory': '%s/tanka' % tld,
          env: {
            GIT_COMMIT_ID: '${{ github.sha }}',
          },
        },
        { run: 'kubectl wait --for=condition=Ready -l "name=backend-app-api-${{ env.APP_ENV }}" pod --timeout=5m' },
        { run: 'kubectl get pods' },
        {
          run: 'make mail_templates_push',
          'working-directory': '%s/backend' % tld,
          env: {
            POSTMARK_SERVER_TOKEN: '${{ secrets.POSTMARK_SERVER_TOKEN }}',
          },
        },
        {
          uses: 'actions/upload-artifact@v4',
          with: {
            name: 'frontend',
            'if-no-files-found': 'error',
            path: |||
              %(tld)s/frontend_vendor/dist/
              %(tld)s/frontend_ws/dist/
              %(tld)s/frontend_wso/dist/
            ||| % { tld: tld },
          },
        },
      ],
    },
  },
}
