local job = import 'job.libsonnet';
local terraform = import 'terraform.libsonnet';
local workflow = import 'workflow.libsonnet';

local tld = 'app_isi/terraform';
local paths = ['%s/**/*' % tld];

{
  name: 'App Isi CI Terraform',
  on: workflow.onPushWithMain + workflow.onPRWithSelf(std.thisFile) {
    push+: { paths+: paths },
    pull_request+: { paths+: paths },
  },
  defaults: workflow.defaults {
    run+: {
      'working-directory': tld,
    },
  },
  concurrency: workflow.concurrency,
  jobs: {
    lint: job.ubuntu {
      name: 'Lint',
      steps+: [
        terraform.taskTerraformLintersSetupTflintV2,
        {
          name: 'Lint TFLint',
          run: |||
            tflint --version
            tflint --init
            make lint
          |||,
        },
      ],
    },
    check: job.ubuntu {
      name: 'Check',
      permissions+: {
        'pull-requests': 'write',
      },
      steps+: [
        terraform.taskHashicorpSetupTerraformV2,
        {
          name: 'Check TFFmt',
          run: 'make check_tffmt',
        },
        {
          name: 'Check TFSec',
          uses: 'aquasecurity/tfsec-pr-commenter-action@v1.3.1',
          with: {
            tfsec_version: 'v1.28.1',
            tfsec_args: '--config-file tfsec.yml',
            github_token: '${{ secrets.GITHUB_TOKEN }}',
          },
        },
      ],
    },
  },
}
