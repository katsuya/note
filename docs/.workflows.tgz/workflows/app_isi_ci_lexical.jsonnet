local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

local tld = 'app_isi/vendor/lexical';
local paths = ['%s/**/*' % tld];

{
  name: 'App Isi CI Lexical',
  on: workflow.onPushWithMain + workflow.onPRWithSelf(std.thisFile) {
    pull_request+: { paths+: paths },
  },
  defaults: workflow.defaults {
    run+: {
      'working-directory': tld,
    },
  },
  concurrency: workflow.concurrency,
  jobs: {
    build: job.ubuntu + job.node(tld) {
      name: 'Build',
      steps+: [
        { run: 'npm run build' },
      ],
    },
    check: job.ubuntu + job.node(tld) {
      name: 'Check',
      steps+: [
        { run: 'npx tsc' },
      ],
    },
    test_unit: job.ubuntu + job.node(tld) {
      name: 'Unit Test',
      steps+: [
        { run: 'npm run test-unit' },
      ],
    },
  },
}
