# workflows

workflowはソースコードや各cloudの秘密鍵などにアクセスできるため、基本
的にsecureな設定に倒した設計や運用してください。ただ、保守的にしすぎる
とDXを阻害するので常にコストとベネフィットを考慮した意思決定を行いたい
ですね。基本的なポリシーは以下です。

- githubやawsの公式のactionsを積極的に使う
- 既存のworkflowに極力併せる

workflowはすべてJsonnetで管理しています。Jsonnetはymlを生成するためツ
ールで以下の理由で使用しています。

- 常に有効なymlを出力するため、無効なymlをコミットするエラーを排除できる。
- 複数のworkflowを標準化できる。
    - 全てのジョブでタイムアウト、同時実行、権限などを安全に設定できます。

Jsonnetの詳細は以下を参照してください。

- https://jsonnet.org/learning/tutorial.html

サポートしているIDEは以下になります。

- [VS Code](https://github.com/grafana/vscode-jsonnet)
- [IntelliJ](https://plugins.jetbrains.com/plugin/18752-jsonnet-language-server)
- [Vim](https://github.com/google/vim-jsonnet)

## Usage

Jsonnetをymlに変換するために以下のコマンドを使用してください。

```bash
make all      # すべてのworkflowのjsonnetからymlを生成
make xxx.yml  # xxx.jsonからxxx.ymlを生成
make fmt      # すべてのjsonnetをフォーマット
make check    # すべてのjsonnetのlint
```

## workflowの一覧

| Workflow名                                                                                         | 詳細                                                              |
|----------------------------------------------------------------------------------------------------|--------------------------------------------------------------------|
| [app_isi_cd_dev_deploy_all](./app_isi_cd_dev_deploy_all.yml)                                       | 開発環境への`app_isi`のdeploy                                       |
| [app_isi_cd_prod_deploy_all](./app_isi_cd_prod_deploy_all.yml)                                     | 本番環境への`app_isi`のdeploy                                       |
| [app_isi_ci](./app_isi_ci.yml)                                                                     | `app_isi`で`make build`と`make check`の実行                        |
| [app_isi_ci_build_image](./app_isi_ci_build_image.yml)                                             | `app_isi`のimageのbuildと`make test`とimageのpushの実行             |
| [app_isi_ci_build_image_base](./app_isi_ci_build_image_base.yml)                                   | `app_isi`のbase imageのbuildとpushの実行             |
| [app_isi_ci_e2e_build_image](./app_isi_ci_e2e_build_image.yml)                                     | `app_isi/e2e`のimageのbuildとpushの実行                             |
| [app_isi_ci_firebase_emulator_build_image](./app_isi_ci_firebase_emulator_build_image.yml)         | `app_isi/firebase_emulator`のbase imageのbuildとpushの実行             |
| [app_isi_ci_install](./app_isi_ci_install.yml)                                                     | macOS環境の`app_isi`で`npm ci`の実行                                |
| [app_isi_ci_lexical](./app_isi_ci_lexical.yml)                                                     | `app_isi/vendor/lexical`でbuildとcheckとtestを実行                  |
| [app_isi_ci_lint](./app_isi_ci_lint.yml)                                                           | `app_isi`の3種類のlinterを実行                                      |
| [app_isi_ci_terraform](./app_isi_ci_terraform.yml)                                                 | `app_isi/terraform`のterraformのlintとfmtの実行                     |
| [app_isi_e2e_prev_synthetic_monitoring](./app_isi_e2e_prev_synthetic_monitoring.yml)               | 日次でのプレビュー環境の`app_isi`の外形監視                          |
| [app_isi_e2e_prod_synthetic_monitoring](./app_isi_e2e_prod_synthetic_monitoring.yml)               | 日次での本番環境の`app_isi`の外形監視                               |
| [app_isi_perf_1w_prev_ws](./app_isi_perf_1w_prev_ws.yml)                                           | 週次でのプレビュー環境の`app_isi`のパフォーマンス監視               |
| [app_isi_watchdog_1d_cleaning_artifact_registry](./app_isi_watchdog_1d_cleaning_artifact_registry.yml) | 日次での`app_isi`で使用していないdocker imageの削除                |
| [app_isi_watchdog_1d_cleaning_assets](./app_isi_watchdog_1d_cleaning_assets.yml)                   | 日次での`app_isi`で使用していないassetsの削除                       |
| [github_workflows_lint](./github_workflows_lint.yml)                                               | `.github/workflows`のgithub workflowのlint                          |
| [infra_gcp_ci](./infra_gcp_ci.yml)                                                                 | `infra_gcp`以下のterraformのlintとfmtの実行                         |
| [super_linter](./super_linter.yml)                                                                 | コード全体に対してsuper lintを実行                                  |
| [tool_lfs_warning](./tool_lfs_warning.yml)                                                         | 大容量ファイルがcommitされた場合に警告をPRのコメントに追加          |

## workflowのルール

以下のルールに沿ってください。

- workflowのファイル名は以下:
  - `${TLD}_(ci|cd)?_(${HC_ENV})?_${機能名}`
- workflowの `name` は必ず設定する。WEBコンソールのactionsタブを見たと
  きに揃うようにする。

## onの指定の方針

基本的に新規で追加するworkflowは、pull_requestの特定のpathsで実行され
るように指定してください。

```yaml
on:
  pull_request:
    paths:
      - app_isi/**/*
```

さらに主要なブランチで実行する場合は以下の指定を追加でお願いします。

```yaml
on:
  pull_request:
    branches-ignore:
      - master
      - maint-app_isi
      - pu
      - RFC[0-9][0-9][0-9][0-9]
  push:
    branches:
      - master
      - maint-app_isi
      - pu
      - RFC[0-9][0-9][0-9][0-9]
```

## Container Registryとの認証

Container Registryとの認証はworkflowの実行者の認証情報を使用してくださ
い。

```yaml
permissions:
  packages: read
  # 書き込みが必要な場合は以下:
  # packages: write
container:
  image: ghcr.io/owner/image
  credentials:
    username: ${{ github.actor }}
    password: ${{ secrets.github_token }}
```

Container Registryとの認可のために、
https://docs.github.com/en/packages/learn-github-packages/configuring-a-packages-access-control-and-visibility#ensuring-github-codespaces-access-to-your-package
に従って設定してください。指定するrepositoryは、workflowが含まれている
repositoryになります。ほとんどの場合は、hicustomer/hc です。

PAT(classic)を別途発行して認証・認可が可能ですが、セキュリティ上危険な
ためやらないでください。何をやっているか理解されているかたのみ使用が許
可されています。

```yaml
container:
  image: ghcr.io/owner/image
  credentials:
    username: ${{ github.repository_owner }}
    password: ${{ PAT }}
```

参考資料は以下:

- https://docs.github.com/en/packages/learn-github-packages/about-permissions-for-github-packages#about-scopes-and-permissions-for-package-registries
- https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-container-registry#authenticating-to-the-container-registry

## GITHUB_TOKENについて

`secrets.GITHUB_TOKEN`はデフォルトで以下の権限のみが付与されています。
追加の権限が必要な場合は適宜workflowもしくはjob単位で指定してください。
その際に、既存の権限は全て上書きされるので気をつけてください。

```yaml
permissions:
  contents: read
```

オペレーションごとにどの権限が必要かどうかを確認する際は、以下の参考資料
を参照してください。

- https://docs.github.com/en/actions/security-guides/automatic-token-authentication#permissions-for-the-github_token
- https://docs.github.com/en/rest/overview/permissions-required-for-github-apps?apiVersion=2022-11-28

## 利用可能なactionについて

利用可能なactionsは、以下 + https://github.com/actions +
https://github.com/github で公開されているactionになります。追加で使用
したいものがある場合は、orgの権限を保持しているメンバーにリクエストし
てください。

```
Asana/create-app-attachment-github-action@*,
actionsdesk/lfs-warning@*,
andresz1/size-limit-action@v1,
aquasecurity/tfsec-pr-commenter-action@*,
aws-actions/configure-aws-credentials@*,
codecov/codecov-action@*,
docker/build-push-action@*,
docker/login-action@*,
docker/setup-buildx-action@*,
golangci/golangci-lint-action@*,
google-github-actions/auth@*,
google-github-actions/get-gke-credentials@*,
google-github-actions/setup-gcloud@*,
hashicorp/setup-terraform@*,
iryanbell/scc-docker-action@*,
ppremk/lfs-warning@*,
reviewdog/action-actionlint@*,
reviewdog/action-eslint@*,
reviewdog/action-setup@*,
ruby/setup-ruby@*,
terraform-linters/setup-tflint@*,
zendesk/setup-jsonnet@*,
```

## AWSとの認証

極力AWSが公開しているactionsを使用する方針です。現状ではほとんど使えな
いですが。

- https://github.com/aws-actions

現状使えるactionは以下になります。

| action                           | 備考                                  |
| -------------------------------- | ------------------------------------- |
| configure-aws-credentials        | 認証の設定に追加                      |
| aws-codebuild-run-project        | buildが終わるまでwaitしてくれる       |
| aws-cloudformation-github-deploy | CFnのtemplateのdeployに使う           |
| amazon-ecr-login                 | マルチアカウントのECRに対応したら使う |

AWS用のsecretsは以下になります。

| parameter                  | 備考             |
| -------------------------- | ---------------- |
| DEV_AWS_ACCESS_KEY_ID      | hicustomer-dev用 |
| DEV_AWS_SECRET_ACCESS_KEY  | hicustomer-dev用 |
| PROD_AWS_ACCESS_KEY_ID     | hicustomer用     |
| PROD_AWS_SECRET_ACCESS_KEY | hicustomer用     |

認証のworkflowsでの指定は以下のように行ってください。環境変数に設定し
た値は極力logに出力しないように気をつけてください。

```yaml
- name: Configure AWS credentials
  uses: aws-actions/configure-aws-credentials@v1
  with:
    aws-access-key-id: ${{ secrets.DEV_AWS_ACCESS_KEY_ID }}
    aws-secret-access-key: ${{ secrets.DEV_AWS_SECRET_ACCESS_KEY }}
    aws-region: ap-northeast-1
```

## GCPとの認証

GCPとの認証には必ず以下のように、 `google-github-actions/auth` を
Workload Identity Federationの認証方式で使用してください。

指定する workload_identity_provider と service_account は以下になります。

- workload_identity_provider
  - `hc-shared-service-account` プロジェクトに配置されている GitHub
    Actions 用の Workload Identity Pool を使用する。
  - Workload Identity Pool/Provider は
    `infra_gcp/shared_service_account` の Terraform で管理する。
- service_account
  - TLD 毎に用途に応じて用意されたサービスアカウントを使用する。各サー
    ビスアカウントは対応するプロジェクトに存在するサービスアカウントと
    する。
  - サービスアカウントとサービスアカウント紐づける IAM Role は基本的に
    `infra_gcp/org` の Terraform で管理する。
    - Service リソース単位で IAM Role の範囲を絞りたい場合は、別の
      Terraform で定義しても問題なし。
      - 例、`infra_gcp/shared_artifact` の Artifact Registry
        `hc-app-isi` リポジトリ
  - Workload Identity Pool とサービスアカウントのマッピングは
    `infra_gcp/shared_service_account` の Terraform で管理する。

参考資料は以下:

- https://github.com/google-github-actions/auth
- https://github.com/terraform-google-modules/terraform-google-github-actions-runners/tree/master/modules/gh-oidc
- https://cloud.google.com/blog/products/identity-security/enabling-keyless-authentication-from-github-actions
- https://docs.github.com/en/actions/deployment/security-hardening-your-deployments/configuring-openid-connect-in-google-cloud-platform

## 参考資料

- https://securitylab.github.com/research/github-actions-preventing-pwn-requests/
- https://securitylab.github.com/research/github-actions-untrusted-input/
- https://securitylab.github.com/research/github-actions-building-blocks/
