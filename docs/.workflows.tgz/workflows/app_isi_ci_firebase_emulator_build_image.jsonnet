local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

local tld = 'app_isi/firebase_emulator';

{
  name: 'App Isi CI Firebase Emulator Build Image',
  on: workflow.onPRWithSelf(std.thisFile),
  defaults: workflow.defaults {
    run+: {
      'working-directory': tld,
    },
  },
  concurrency: workflow.concurrency,
  jobs: {
    build_test_push: job.ubuntu + job.disableIfDependabot {
      name: 'Build and Push image',
      permissions+: {
        packages: 'write',
      },
      steps+: [
        {
          name: 'Extract firebase-tools version',
          run: |||
            FIREBASE_TOOLS_VERSION=$(sed -nE 's/.*firebase-tools@([0-9.]+).*/\1/p' Dockerfile)
            if [ -z "$FIREBASE_TOOLS_VERSION" ]; then
              echo "Error: Failed to extract firebase-tools version from Dockerfile"
              exit 1
            fi
            echo "FIREBASE_TOOLS_VERSION=${FIREBASE_TOOLS_VERSION}"
            echo "FIREBASE_TOOLS_VERSION=${FIREBASE_TOOLS_VERSION}" >> "$GITHUB_ENV"
          |||,
        },
        {
          name: 'Set up Docker Buildx',
          // https://github.com/docker/setup-buildx-action
          uses: 'docker/setup-buildx-action@v3',
        },
        {
          name: 'Login to GitHub Container Registry',
          // https://github.com/docker/login-action
          uses: 'docker/login-action@v3',
          with: {
            registry: 'ghcr.io',
            username: '${{ github.actor }}',
            password: '${{ secrets.github_token }}',
          },
        },
        {
          name: 'Check if image tag already exists',
          run: |||
            if docker manifest inspect ghcr.io/hicustomer/hc-app-isi-firebase-emulator:firebase-tools${{ env.FIREBASE_TOOLS_VERSION }} > /dev/null 2>&1; then
              echo "Image tag already exists. Skipping build and push."
              echo "TAG_EXISTS=true" >> "$GITHUB_ENV"
            else
              echo "Image tag does not exist. Proceeding with build and push."
              echo "TAG_EXISTS=false" >> "$GITHUB_ENV"
            fi
          |||,
        },
        {
          name: 'Build and Push',
          'if': "env.TAG_EXISTS == 'false'",
          // https://github.com/docker/build-push-action
          uses: 'docker/build-push-action@v6',
          with: {
            context: './%s' % tld,
            push: true,
            platforms: |||
              linux/amd64
              linux/arm64/v8
            |||,
            tags: |||
              ghcr.io/hicustomer/hc-app-isi-firebase-emulator:firebase-tools${{ env.FIREBASE_TOOLS_VERSION }}
            |||,
          },
        },
      ],
    },
  },
}
