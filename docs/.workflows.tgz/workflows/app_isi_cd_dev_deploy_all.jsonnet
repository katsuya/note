local appIsi = import 'app_isi.libsonnet';
local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

local tld = '/app';
local sa = 'oidc-github-actions@hc-app-isi-dev.iam.gserviceaccount.com';

{
  name: 'App Isi CD Dev Deploy All',
  on: workflow.debug {
    push+: {
      branches+: [
        'deploy/app_isi/prev',
        'deploy/app_isi/stg01',
        'deploy/app_isi/stg02',
        'deploy/app_isi/stg03',
        'deploy/app_isi/stg04',
        'deploy/app_isi/stg05',
      ],
    },
    workflow_run: {
      workflows: ['App Isi CI Build Image'],
      types: ['completed'],
      branches: [
        'prev',
        'stg01',
        'stg02',
        'stg03',
        'stg04',
        'stg05',
      ],
    },
  },
  env: {
    NODE_OPTIONS: '--max-old-space-size=4096',
  },
  defaults: workflow.defaults {
    run+: {
      'working-directory': tld,
    },
  },
  concurrency: workflow.concurrency,
  jobs: {
    deploy: appIsi.container('${{ github.event.workflow_run.head_sha || github.sha }}') +
            job.setAppEnv + job.ubuntuWithoutCheckout + job.gcloud(sa) {
      name: 'Deploy',
      'if': "${{ github.event_name != 'workflow_run' || github.event.workflow_run.conclusion == 'success' }}",
      'timeout-minutes': 20,
      environment: 'dev',
      steps+: [
        {
          uses: 'google-github-actions/get-gke-credentials@v2',
          with: {
            cluster_name: 'projects/hc-app-isi-dev/locations/asia-northeast1/clusters/cluster-auto-01',
          },
        },
        { run: 'kubectl get pods' },
        {
          run: 'make release_dev_frontend',
          env: {
            VITE_SENTRY_AUTH_TOKEN: '${{ secrets.VITE_SENTRY_AUTH_TOKEN }}',
            VITE_SENTRY_RELEASE_VERSION: '${{ github.event.workflow_run.head_sha || github.sha }}',
          },
        },
        {
          run: 'echo yes | make apply_dev',
          'working-directory': '%s/tanka' % tld,
          env: {
            GIT_COMMIT_ID: '${{ github.event.workflow_run.head_sha || github.sha }}',
          },
        },
        { run: 'kubectl wait --for=condition=Ready -l "name=backend-app-api-${{ env.APP_ENV }}" pod --timeout=5m' },
        { run: 'kubectl get pods' },
        {
          run: 'make mail_templates_push',
          'working-directory': '%s/backend' % tld,
          env: {
            POSTMARK_SERVER_TOKEN: '${{ secrets.POSTMARK_SERVER_TOKEN }}',
          },
        },
        {
          uses: 'actions/upload-artifact@v4',
          with: {
            name: 'frontend',
            'if-no-files-found': 'error',
            path: |||
              %(tld)s/frontend_vendor/dist/
              %(tld)s/frontend_ws/dist/
              %(tld)s/frontend_wso/dist/
            ||| % { tld: tld },
          },
        },
      ],
    },
  },
}
