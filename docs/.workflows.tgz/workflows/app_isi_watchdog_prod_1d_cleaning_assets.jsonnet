local gcp = import 'gcp.libsonnet';
local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

local tld = 'app_isi';

{
  name: 'App Isi Watchdog Prod Cleaning Assets Every Day',
  on: workflow.onPRWithSelf(std.thisFile) {
    schedule: [
      {
        cron: '0 0 * * *',
      },
    ],
  },
  defaults: workflow.defaults,
  concurrency: workflow.concurrency,
  jobs: {
    cleaning_assets_every_day: job.ubuntu + job.node(tld) {
      name: 'Cleaning Assets Every Day',
      permissions+: {
        'id-token': 'write',
      },
      steps+: [
        {
          id: 'auth-hc-app-isi-prod',
          name: 'Authenticate to Google Cloud (hc-app-isi-prod project)',
          uses: 'google-github-actions/auth@v2',
          with: {
            workload_identity_provider: gcp.workloadIdentityProvider(860166587716),
            service_account: 'oidc-github-actions@hc-app-isi-prod.iam.gserviceaccount.com',
          },
        },
        {
          name: 'Cleanup assets on the hc-app-isi-prod project',
          'working-directory': 'app_isi/watchdog',
          run: |||
            # NOTE: Run in dry-run mode for a while, and if no assets that
            # shouldn't be deleted are being removed, add --run to enable the
            # batch.
            #
            # ./cleanup_assets.ts --run --bucket hc-app-isi-frontend-ws-bucket-asia1-prod
            # ./cleanup_assets.ts --run --bucket hc-app-isi-frontend-wso-bucket-asia1-prod
            # ./cleanup_assets.ts --run --bucket hc-app-isi-frontend-vendor-bucket-asia1-prod

            ./cleanup_assets.ts --bucket hc-app-isi-frontend-ws-bucket-asia1-prod
            ./cleanup_assets.ts --bucket hc-app-isi-frontend-wso-bucket-asia1-prod
            ./cleanup_assets.ts --bucket hc-app-isi-frontend-vendor-bucket-asia1-prod
          |||,
        },
      ],
    },
  },
}
