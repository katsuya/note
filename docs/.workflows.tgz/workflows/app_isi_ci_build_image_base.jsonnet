local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

local tld = 'app_isi';

{
  name: 'App Isi CI Build Image Base',
  on: workflow.onPRWithSelf(std.thisFile),
  defaults: workflow.defaults {
    run+: {
      'working-directory': tld,
    },
  },
  concurrency: workflow.concurrency,
  jobs: {
    build_test_push: job.ubuntu + job.disableIfDependabot {
      name: 'Build and Push image',
      permissions+: {
        packages: 'write',
      },
      steps+: [
        {
          name: 'Extract base tag',
          run: |||
            BASE_TAG=$(sed -nE 's/^FROM ghcr.io\/hicustomer\/hc-app-isi-base:(.*)/\1/p' Dockerfile)
            if [ -z "$BASE_TAG" ]; then
              echo "Error: Failed to extract tag from Dockerfile"
              exit 1
            fi
            echo "BASE_TAG=${BASE_TAG}"
            echo "BASE_TAG=${BASE_TAG}" >> "$GITHUB_ENV"
          |||,
        },
        {
          name: 'Set up Docker Buildx',
          // https://github.com/docker/setup-buildx-action
          uses: 'docker/setup-buildx-action@v3',
        },
        {
          name: 'Login to GitHub Container Registry',
          // https://github.com/docker/login-action
          uses: 'docker/login-action@v3',
          with: {
            registry: 'ghcr.io',
            username: '${{ github.actor }}',
            password: '${{ secrets.github_token }}',
          },
        },
        {
          name: 'Check if image tag already exists',
          run: |||
            if docker manifest inspect ghcr.io/hicustomer/hc-app-isi-base:${{ env.BASE_TAG }} > /dev/null 2>&1; then
              echo "Image tag already exists. Skipping build and push."
              echo "BASE_TAG_EXISTS=true" >> "$GITHUB_ENV"
            else
              echo "Image tag does not exist. Proceeding with build and push."
              echo "BASE_TAG_EXISTS=false" >> "$GITHUB_ENV"
            fi
          |||,
        },
        {
          name: 'Build and Push',
          'if': "env.BASE_TAG_EXISTS == 'false'",
          // https://github.com/docker/build-push-action
          uses: 'docker/build-push-action@v6',
          with: {
            context: './%s' % tld,
            push: true,
            platforms: |||
              linux/amd64
              linux/arm64/v8
            |||,
            target: 'base',
            tags: |||
              ghcr.io/hicustomer/hc-app-isi-base:${{ env.BASE_TAG }}
            |||,
          },
        },
      ],
    },
  },
}
