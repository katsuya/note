local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

local tld = 'app_isi';
local paths = ['%s/**/*' % tld];
local sa = 'oidc-github-actions@hc-app-isi-dev.iam.gserviceaccount.com';

{
  name: 'App Isi CI Build Image',
  on: workflow.onPushWithMain + workflow.onPRWithSelf(std.thisFile) {
    pull_request+: { paths+: paths },
  },
  env: {
    NODE_OPTIONS: '--max-old-space-size=4096',
  },
  defaults: workflow.defaults {
    run+: {
      'working-directory': tld,
    },
  },
  concurrency: workflow.concurrency,
  jobs: {
    build_test_push: job.ubuntu + job.gcloudWithoutKubectrl(sa) + job.disableIfDependabot {
      name: 'Build, Test and Push',
      permissions+: {
        packages: 'write',
      },
      'timeout-minutes': 30,
      steps+: [
        {
          name: 'Set up Docker Buildx',
          // https://github.com/docker/setup-buildx-action
          uses: 'docker/setup-buildx-action@v3',
        },
        {
          name: 'Login to GitHub Container Registry',
          // https://github.com/docker/login-action
          uses: 'docker/login-action@v3',
          with: {
            registry: 'ghcr.io',
            username: '${{ github.actor }}',
            password: '${{ secrets.github_token }}',
          },
        },
        {
          name: 'Login to Google Artifact Registry',
          uses: 'docker/login-action@v3',
          with: {
            registry: 'asia-docker.pkg.dev',
            username: 'oauth2accesstoken',
            password: '${{ steps.google_github_actions_auth.outputs.access_token }}',
          },
        },
        {
          name: 'Build',
          // https://github.com/docker/build-push-action
          uses: 'docker/build-push-action@v6',
          with: {
            context: './app_isi',
            load: true,
            'build-args': 'TAG=${{ github.sha }}',
            'cache-from': 'type=registry,ref=ghcr.io/hicustomer/hc-app-isi:latest',
            'cache-to': 'type=registry,ref=ghcr.io/hicustomer/hc-app-isi:latest,mode=max',
            tags: |||
              hc-app-isi:latest
              ghcr.io/hicustomer/hc-app-isi:git-commit-id-${{ github.sha }}
              asia-docker.pkg.dev/hc-shared-artifact/hc-app-isi/hc-app-isi:git-commit-id-${{ github.sha }}
            |||,
          },
        },
        {
          name: 'Start containers',
          run: |||
            docker compose up -d backend_api
            docker compose ps
          |||,
        },
        {
          name: 'Test',
          run: |||
            make build_impersonated_access_token_dev
            docker compose run --rm \
              -v "$(readlink -f ./tmp):/app/tmp" \
              -e NODE_ENV=test \
              -e TS_NODE_PROJECT=/app/backend/tsconfig.json \
              -e GOOGLE_APPLICATION_CREDENTIALS= \
              -e GOOGLE_APPLICATION_ACCESS_TOKEN=/app/tmp/access_token.json \
              -e FIREBASE_AUTH_EMULATOR_HOST=firebase_emulator:4904 \
              -e FIREBASE_STORAGE_EMULATOR_HOST=firebase_emulator:4905 \
              -e FIRESTORE_EMULATOR_HOST=firebase_emulator:4906 \
              backend_api make test_all
            docker compose run --rm \
              -e TS_NODE_PROJECT=/app/frontend_ws/tsconfig.json \
              -e NODE_ENV=test \
              frontend_ws make test
            docker compose run --rm \
              -e TS_NODE_PROJECT=/app/frontend_wso/tsconfig.json \
              -e NODE_ENV=test \
              frontend_wso make test
            docker compose run --rm \
              -e TS_NODE_PROJECT=/app/frontend_vendor/tsconfig.json \
              -e NODE_ENV=test \
              frontend_vendor make test
            docker compose run --rm \
              -e TS_NODE_PROJECT=/app/lib_lexical/tsconfig.json \
              -e NODE_ENV=test \
              backend_api bash -c 'cd ../lib_lexical && make test'
          |||,
        },
        {
          name: 'Lint DDL',
          run: |||
            docker compose run --rm \
              -e NODE_ENV=test \
              -e TS_NODE_PROJECT=/app/backend/tsconfig.json \
              backend_api make lint_ddl
          |||,
        },
        {
          name: 'Stop containers',
          run: 'docker compose down',
          'if': 'always()',
        },
        {
          name: 'Push',
          run: |||
            docker push ghcr.io/hicustomer/hc-app-isi:git-commit-id-${{ github.sha }} &
            docker push \
              asia-docker.pkg.dev/hc-shared-artifact/hc-app-isi/hc-app-isi:git-commit-id-${{ github.sha }} &
            wait
          |||,
        },
      ],
    },
  },
}
