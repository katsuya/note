local gcp = import 'gcp.libsonnet';
local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

local tld = 'app_isi';

{
  name: 'App Isi Watchdog Cleaning Artifact Registry Every Day',
  on: workflow.onPRWithSelf(std.thisFile),
  defaults: workflow.defaults {
    run+: {
      'working-directory': tld,
    },
  },
  concurrency: workflow.concurrency,
  jobs: {
    cleaning_artifact_registry_every_day: job.ubuntu + job.node(tld) {
      name: 'Cleaning Artifact Registry Every Day',
      permissions+: {
        'id-token': 'write',
      },
      steps+: [
        {
          id: 'app-isi-dev',
          name: 'Authenticate to Google Cloud (hc-app-isi-dev project)',
          uses: 'google-github-actions/auth@v2',
          with: {
            workload_identity_provider: gcp.workloadIdentityProvider(860166587716),
            service_account: 'oidc-github-actions@hc-app-isi-dev.iam.gserviceaccount.com',
          },
        },
        {
          id: 'app-isi-prod',
          name: 'Authenticate to Google Cloud (hc-app-isi-prod project)',
          uses: 'google-github-actions/auth@v2',
          with: {
            workload_identity_provider: gcp.workloadIdentityProvider(860166587716),
            service_account: 'oidc-github-actions@hc-app-isi-prod.iam.gserviceaccount.com',
          },
        },
        {
          id: 'shared-artifact',
          name: 'Authenticate to Google Cloud (hc-shared-artifact project)',
          uses: 'google-github-actions/auth@v2',
          with: {
            workload_identity_provider: gcp.workloadIdentityProvider(860166587716),
            service_account: 'oidc-github-actions@hc-shared-artifact.iam.gserviceaccount.com',
          },
        },
        {
          name: 'Cleanup artifact registry on the hc-shared-artifact project',
          'working-directory': 'app_isi/watchdog',
          run: |||
            # NOTE: Run in dry-run mode for a while, and if no images that
            # shouldn't be deleted are being removed, add --run to enable the
            # batch.
            #
            # ./cleanup_artifact_registry.ts --run

            ./cleanup_artifact_registry.ts
          |||,
          env: {
            HC_APP_ISI_DEV_CREDENTIAL_FILE_PATH: '${{ steps.app-isi-dev.outputs.credentials_file_path }}',
            HC_APP_ISI_PROD_CREDENTIAL_FILE_PATH: '${{ steps.app-isi-prod.outputs.credentials_file_path }}',
            HC_SHARED_ARTIFACT_CREDENTIAL_FILE_PATH: '${{ steps.shared-artifact.outputs.credentials_file_path }}',
          },
        },
      ],
    },
  },
}
