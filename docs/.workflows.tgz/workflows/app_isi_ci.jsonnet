local appIsi = import 'app_isi.libsonnet';
local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

local tld = 'app_isi';
local paths = ['%s/**/*' % tld];
local containerBase = appIsi.containerBase;

{
  name: 'App Isi CI',
  on: workflow.onPushWithMain + workflow.onPRWithSelf(std.thisFile) {
    push+: { paths+: paths },
    pull_request+: { paths+: paths },
  },
  env: {
    NODE_OPTIONS: '--max-old-space-size=4096',
  },
  defaults: workflow.defaults {
    run+: {
      'working-directory': tld,
    },
  },
  concurrency: workflow.concurrency,
  jobs: {
    build: job.ubuntu + job.node(tld) {
      name: 'Build',
      permissions+: {
        issues: 'write',
        'pull-requests': 'write',
        contents: 'write',
      },
      steps+: [
        { run: 'make build_vendor_lexical' },
        { run: 'make build_dev -j"$(nproc)"' },
      ],
    },
    check: job.ubuntu + containerBase + job.node(tld) {
      name: 'Check',
      steps+: [
        { run: 'make build_vendor_lexical' },
        { run: 'make check -j"$(nproc)"' },
      ],
    },
  },
}
