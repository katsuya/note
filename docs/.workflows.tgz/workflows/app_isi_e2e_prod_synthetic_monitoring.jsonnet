local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

local tld = 'app_isi';
local sa = 'oidc-github-actions@hc-app-isi-prod.iam.gserviceaccount.com';

{
  name: 'App Isi E2E Prod Synthetic Monitor',
  on: workflow.onPRWithSelf(std.thisFile) {
    schedule: [
      {
        cron: '0 0 * * *',
      },
    ],
  },
  defaults: workflow.defaults {
    run+: {
      'working-directory': tld,
    },
  },
  concurrency: workflow.concurrency,
  jobs: {
    monitoring: job.ubuntu + job.gcloudWithoutKubectrl(sa) + job.node(tld) {
      name: 'Monitor',
      steps+: [
        { run: 'npx playwright install --with-deps' },
        {
          'working-directory': 'app_isi/e2e',
          run: 'make synthetic_monitor_ws',
        },
        {
          'working-directory': 'app_isi/e2e',
          run: 'make synthetic_monitor_wso',
        },
      ],
    },
  },
}
