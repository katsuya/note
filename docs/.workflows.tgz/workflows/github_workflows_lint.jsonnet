local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

local tld = '.github/workflows';
local paths = ['%s/**/*' % tld];

{
  name: 'GitHub Workflows Lint',
  on: workflow.onPushWithMain + workflow.onPRWithSelf(std.thisFile) {
    push+: { paths+: paths },
    pull_request+: { paths+: paths },
  },
  defaults: workflow.defaults {
    run+: {
      'working-directory': tld,
    },
  },
  concurrency: workflow.concurrency,
  jobs: {
    actionlint: job.ubuntu {
      name: 'Actionlint',
      permissions+: {
        'pull-requests': 'write',
      },
      steps+: [
        {
          uses: 'reviewdog/action-actionlint@v1',
          with: {
            reporter: 'github-pr-check',
            fail_on_error: true,
          },
        },
      ],
    },
    check_diff: job.ubuntu {
      name: 'Check Diff',
      steps+: [
        {
          uses: 'zendesk/setup-jsonnet@v12',
          with: { version: 'v0.20.0' },
        },
        {
          run: |||
            make all
            git diff --exit-code
          |||,
        },
        { run: 'make fmt' },
        { run: 'make lint' },
      ],
    },
  },
}
