local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

local tld = 'app_isi/perf';
local paths = ['%s/**/*' % tld];

{
  name: 'App Isi Perf 1w Prev Ws',
  on: workflow.onPRWithSelf(std.thisFile) {
    pull_request+: { paths+: paths },
    schedule: [
      {
        cron: '0 0 * * 0',
      },
    ],
  },
  defaults: workflow.defaults {
    run+: {
      'working-directory': tld,
    },
  },
  concurrency: workflow.concurrency,
  jobs: {
    perf: job.ubuntu + job.node('app_isi') {
      name: 'Perf',
      steps+: [
        {
          name: 'Setup k6',
          uses: 'grafana/setup-k6-action@v1',
          with: {
            'k6-version': '0.44.1',
          },
        },
        {
          name: 'Run k6',
          run: 'make k6_ws',
          env: {
            API_WS_HOST: '${{ vars.HC_APP_ISI_PERF_WS_PREV_URL }}',
            WC: '${{ vars.HC_APP_ISI_PERF_WS_PREV_WC }}',
            CC: '${{ vars.HC_APP_ISI_PERF_WS_PREV_CC }}',
            PAGE_ID: '${{ vars.HC_APP_ISI_PERF_WS_PREV_PAGE_ID }}',
          },
        },
      ],
    },
  },
}
