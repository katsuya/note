local appIsi = import 'app_isi.libsonnet';
local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

local tld = 'app_isi/tanka';
local paths = ['%s/**/*' % tld];

{
  name: 'App Isi CI Tanka',
  on: workflow.onPushWithMain + workflow.onPRWithSelf(std.thisFile) {
    push+: { paths+: paths },
    pull_request+: { paths+: paths },
  },
  defaults: workflow.defaults {
    run+: {
      'working-directory': tld,
    },
  },
  concurrency: workflow.concurrency,
  jobs: {
    fmt: job.ubuntu + appIsi.containerBase {
      name: 'Fmt',
      steps+: [
        { run: 'make fmt' },
      ],
    },
    lint: job.ubuntu + appIsi.containerBase {
      name: 'Lint',
      steps+: [
        { run: 'make lint' },
      ],
    },
  },
}
