local gcp = import 'gcp.libsonnet';
local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

local tld = 'app_isi';

{
  name: 'App Isi Watchdog Dev Cleaning Assets Every Day',
  on: workflow.onPRWithSelf(std.thisFile) {
    schedule: [
      {
        cron: '0 0 * * *',
      },
    ],
  },
  defaults: workflow.defaults,
  concurrency: workflow.concurrency,
  jobs: {
    cleaning_assets_every_day: job.ubuntu + job.node(tld) {
      name: 'Cleaning Assets Every Day',
      permissions+: {
        'id-token': 'write',
      },
      steps+: [
        {
          id: 'auth-hc-app-isi-dev',
          name: 'Authenticate to Google Cloud (hc-app-isi-dev project)',
          uses: 'google-github-actions/auth@v2',
          with: {
            workload_identity_provider: gcp.workloadIdentityProvider(860166587716),
            service_account: 'oidc-github-actions@hc-app-isi-dev.iam.gserviceaccount.com',
          },
        },
        {
          name: 'Cleanup assets on the hc-app-isi-dev project',
          'working-directory': 'app_isi/watchdog',
          run: |||
            ./cleanup_assets.ts --run --bucket hc-app-isi-frontend-ws-bucket-asia1-prev
            ./cleanup_assets.ts --run --bucket hc-app-isi-frontend-wso-bucket-asia1-prev
            ./cleanup_assets.ts --run --bucket hc-app-isi-frontend-vendor-bucket-asia1-prev
          |||,
        },
      ],
    },
  },
}
