local appIsi = import 'app_isi.libsonnet';
local job = import 'job.libsonnet';
local workflow = import 'workflow.libsonnet';

local tld = 'app_isi';
local paths = ['%s/**/*' % tld];
local containerBase = appIsi.containerBase;

{
  name: 'App Isi CI Lint',
  on: workflow.onPushWithMain + workflow.onPRWithSelf(std.thisFile) {
    push+: { paths+: paths },
    pull_request+: { paths+: paths },
  },
  env: {
    NODE_OPTIONS: '--max-old-space-size=4096',
  },
  defaults: workflow.defaults {
    run+: {
      'working-directory': tld,
    },
  },
  concurrency: workflow.concurrency,
  jobs: {
    lint: job.ubuntu + containerBase + job.node(tld) {
      name: 'Lint',
      steps+: [
        { run: 'make lint -k' },
      ],
    },
    lint_for_annotation: job.ubuntu + containerBase + job.node(tld) {
      name: 'Lint For Annotation',
      permissions+: {
        'pull-requests': 'write',
      },
      'timeout-minutes': 30,
      steps+: [
        { run: 'make build_vendor_lexical' },
        {
          uses: 'reviewdog/action-eslint@v1',
          with: {
            // NOTE: https://github.com/reviewdog/reviewdog/issues/1696#issuecomment-2077370044
            // の問題のため、github-pr-checkからgithub-pr-reviewに変更
            reporter: 'github-pr-review',
            fail_on_error: true,
            workdir: tld,
            eslint_flags: '**/*.{js,ts,tsx} -c .eslintrc.ci.json',
            node_options: '--max-old-space-size=8192',
          },
        },
      ],
    },
    lint_sql: job.ubuntu + containerBase {
      name: 'Lint SQL files',
      steps+: [
        {
          name: 'Run pgFormatter',
          run: |||
            make fix_sql
            git config --global --add safe.directory '*'
            git diff --exit-code
          |||,
        },
      ],
    },
  },
}
