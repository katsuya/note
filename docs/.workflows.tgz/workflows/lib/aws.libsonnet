{
  taskConfigureAwsCredentialsV1Dev: {
    name: 'Configure AWS credentials',
    uses: 'aws-actions/configure-aws-credentials@v1',
    with: {
      'aws-access-key-id': '${{ secrets.DEV_AWS_ACCESS_KEY_ID }}',
      'aws-secret-access-key': '${{ secrets.DEV_AWS_SECRET_ACCESS_KEY }}',
      'aws-region': 'ap-northeast-1',
    },
  },
  taskConfigureAwsCredentialsV1Prod: {
    name: 'Configure AWS credentials',
    uses: 'aws-actions/configure-aws-credentials@v1',
    with: {
      'aws-access-key-id': '${{ secrets.PROD_AWS_ACCESS_KEY_ID }}',
      'aws-secret-access-key': '${{ secrets.PROD_AWS_SECRET_ACCESS_KEY }}',
      'aws-region': 'ap-northeast-1',
    },
  },
}
