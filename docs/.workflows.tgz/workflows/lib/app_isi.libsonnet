{
  container(ref):: {
    name: error 'Must override "name"',
    permissions+: {
      packages: 'read',
    },
    container: {
      image: 'ghcr.io/hicustomer/hc-app-isi:git-commit-id-%s' % ref,
      options: '--user root',
      credentials: {
        username: '${{ github.actor }}',
        password: '${{ secrets.github_token }}',
      },
    },
  },
  containerBase:: {
    name: error 'Must override "name"',
    permissions+: {
      packages: 'read',
    },
    container: {
      image: 'ghcr.io/hicustomer/hc-app-isi-base:node20.18.0-bookworm',
      options: '--user root',
      credentials: {
        username: '${{ github.actor }}',
        password: '${{ secrets.github_token }}',
      },
    },
  },
}
