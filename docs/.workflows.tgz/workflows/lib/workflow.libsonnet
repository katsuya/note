{
  // WEBコンソールから実行
  debug:: {
    workflow_dispatch: null,
  },

  // デフォルトのrunnerの実行環境をbashに指定
  //
  // NOTE: https://docs.github.com/en/actions/using-workflows/workflow-syntax-for-github-actions#jobsjob_idstepsrun
  defaults:: {
    run+: {
      shell+: 'bash',
    },
  },

  // 主要なブランチで実行
  onPushWithMain:: self.debug {
    push+: {
      branches+: [
        'master',
        'maint',
        'prev',
        'stg01',
        'stg02',
        'stg03',
        'stg04',
        'stg05',
      ],
    },
  },

  // 該当のworkflowファイルの更新時に実行
  onPRWithSelf(file):: self.debug {
    pull_request+: {
      paths+: [
        '.github/workflows/%s' % file,
      ],
    },
  },

  concurrency:: {
    group: '${{ github.workflow }}-${{ github.ref }}',
    'cancel-in-progress': true,
  },
}
