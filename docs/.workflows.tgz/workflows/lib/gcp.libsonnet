{
  workloadIdentityProvider(id)::
    'projects/%s/locations/global/workloadIdentityPools/github-actions/providers/github-actions-provider' % id,
}
