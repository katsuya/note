{
  disableIfDependabot:: {
    'if': "github.actor != 'dependabot[bot]'",
  },

  ubuntu:: {
    name: error 'Must override "name"',
    'runs-on': 'ubuntu-24.04',
    'timeout-minutes': 15,
    permissions+: {
      contents: 'read',
    },
    steps+: [
      { uses: 'actions/checkout@v4' },
    ],
  },

  ubuntuWithoutCheckout:: {
    name: error 'Must override "name"',
    'runs-on': 'ubuntu-24.04',
    'timeout-minutes': 15,
    permissions+: {
      contents: 'read',
    },
  },

  ubuntuWithRef(ref):: {
    name: error 'Must override "name"',
    'runs-on': 'ubuntu-24.04',
    'timeout-minutes': 15,
    permissions+: {
      contents: 'read',
    },
    steps+: [
      {
        uses: 'actions/checkout@v4',
        with: {
          // NOTE: use default branch if empty string.
          // https://github.com/actions/checkout?tab=readme-ov-file#usage
          ref: ref,
        },
      },
    ],
  },

  node(path):: {
    steps+: [
      {
        uses: 'actions/setup-node@v4',
        with: {
          'node-version-file': '%s/.node-version' % path,
          cache: 'npm',
          'cache-dependency-path': '%s/package-lock.json' % path,
        },
      },
      {
        uses: 'actions/cache@v4',
        id: 'node-cache',
        with: {
          path: |||
            %(path)s/node_modules
            # FIXME: app_isiのnpm workspace対応
            %(path)s/*/node_modules
            # FIXME: e2e playwright対応
            ~/.cache/ms-playwright
          ||| % { path: path },
          key: "actions-cache-node-cache-npm-${{ runner.os }}-${{ hashFiles('%s/package-lock.json') }}" % path,
        },
      },
      {
        'if': "steps.node-cache.outputs.cache-hit != 'true'",
        run: 'npm ci --ddd',
        'working-directory': path,
      },
    ],
  },

  setAppEnv:: {
    steps+: [
      {
        name: 'Set APP_ENV based on workflow_run or default branch',
        run: |||
          BRANCH_NAME="${{ github.event.workflow_run.head_branch || github.ref_name }}"
          APP_ENV=$(basename "$BRANCH_NAME")
          echo "APP_ENV=${APP_ENV}" >> "$GITHUB_ENV"
        |||,
      },
      {
        name: 'Verify APP_ENV',
        run: 'echo "APP_ENV is ${{ env.APP_ENV }}"',
      },
    ],
  },

  go(path):: {
    steps+: [
      {
        uses: 'actions/setup-go@v3',
        with: {
          'go-version-file': '%s/go.mod' % path,
          'check-latest': true,
          cache: true,
        },
      },
      {
        run: 'go version',
        'working-directory': path,
      },
    ],
  },

  gcloud(sa):: {
    local id = '860166587716',
    local pool = 'github-actions/providers/github-actions-provider',

    permissions+: {
      'id-token': 'write',
    },
    steps+: [
      {
        id: 'google_github_actions_auth',
        uses: 'google-github-actions/auth@v2',
        with: {
          workload_identity_provider: 'projects/%s/locations/global/workloadIdentityPools/%s' % [id, pool],
          service_account: sa,
          token_format: 'access_token',
        },
      },
      {
        id: 'google_github_actions_setup_gcloud',
        uses: 'google-github-actions/setup-gcloud@v2',
        with: {
          // version: '421.0.0',
          install_components: 'kubectl,gsutil',
        },
      },
      { run: 'gcloud info' },
    ],
  },

  gcloudWithoutKubectrl(sa):: {
    local id = '860166587716',
    local pool = 'github-actions/providers/github-actions-provider',

    permissions+: {
      'id-token': 'write',
    },
    steps+: [
      {
        id: 'google_github_actions_auth',
        uses: 'google-github-actions/auth@v2',
        with: {
          workload_identity_provider: 'projects/%s/locations/global/workloadIdentityPools/%s' % [id, pool],
          service_account: sa,
          token_format: 'access_token',
        },
      },
      {
        id: 'google_github_actions_setup_gcloud',
        uses: 'google-github-actions/setup-gcloud@v2',
      },
      { run: 'gcloud info' },
    ],
  },
}
