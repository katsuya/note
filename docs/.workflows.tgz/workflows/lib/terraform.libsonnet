{
  taskHashicorpSetupTerraformV2: {
    name: 'Setup Terraform',
    uses: 'hashicorp/setup-terraform@v2',
    with: {
      terraform_version: '1.1.8',
    },
  },
  taskTerraformLintersSetupTflintV2: {
    name: 'Setup TFLint',
    uses: 'terraform-linters/setup-tflint@v2',
    with: {
      tflint_version: 'v0.43.0',
    },
  },
}
